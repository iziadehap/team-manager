import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/errors/app_exception.dart';
import '../../cubits/auth/auth_cubit.dart';
import '../../models/app_user.dart';
import '../../models/team.dart';
import '../../router/app_router.dart';
import '../../services/team_service.dart';
import '../../widgets/error_banner.dart';

class TeamsScreen extends StatefulWidget {
  const TeamsScreen({super.key});

  @override
  State<TeamsScreen> createState() => _TeamsScreenState();
}

class _TeamsScreenState extends State<TeamsScreen> {
  AppUser? _user;
  final _pendingCounts = <String, int>{};
  bool _isLoadingCounts = false;
  String? _lastLoadedTeamIds; // Track last loaded teams to avoid reloading

  @override
  void initState() {
    super.initState();
    _loadUser();
  }

  Future<void> _loadUser() async {
    final authCubit = context.read<AuthCubit>();
    await authCubit.loadProfile();
    final profile = authCubit.state.profile;
    if (mounted) setState(() => _user = profile);
  }

  // Only load counts when teams actually change
  Future<void> _refreshPendingCounts(List<Team> teams) async {
    // Skip if already loading or teams are empty
    if (_isLoadingCounts || teams.isEmpty) return;
    
    // Create a unique key for current teams
    final teamIdsKey = teams.map((t) => t.id).join(',');
    
    // Skip if we already loaded counts for these exact teams
    if (_lastLoadedTeamIds == teamIdsKey) return;
    
    _isLoadingCounts = true;
    
    final service = context.read<TeamService>();
    final newCounts = <String, int>{};
    
    for (final team in teams) {
      try {
        final count = await service.pendingTaskCount(team.id);
        newCounts[team.id] = count;
      } catch (e) {
        print('Error loading pending count for ${team.id}: $e');
        newCounts[team.id] = 0;
      }
    }
    
    if (mounted) {
      setState(() {
        _pendingCounts.clear();
        _pendingCounts.addAll(newCounts);
        _lastLoadedTeamIds = teamIdsKey;
      });
    }
    
    _isLoadingCounts = false;
  }

  Future<void> _leaveTeam(Team team) async {
    final userId = context.read<AuthCubit>().state.userId;
    if (userId == null) return;
    try {
      await context.read<TeamService>().leaveTeam(
            userId: userId,
            teamId: team.id,
          );
      // Clear the cache so counts reload after leaving
      _lastLoadedTeamIds = null;
      await _loadUser();
    } on AppException catch (e) {
      if (mounted) showErrorSnackBar(context, e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final teamService = context.read<TeamService>();
    final teamIds = _user?.teamIds ?? [];

    return Scaffold(
      appBar: AppBar(
        title: const Text('MY TEAMS'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {},
          ),
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () => context.push(AppRoutes.profile),
          ),
        ],
      ),
      body: _user == null
          ? const Center(child: CircularProgressIndicator())
          : teamIds.isEmpty
              ? _EmptyTeams(
                  onCreate: () => context.push(AppRoutes.createTeam),
                  onJoin: () => context.push(AppRoutes.joinTeam),
                )
              : StreamBuilder<List<Team>>(
                  stream: teamService.watchUserTeams(teamIds),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    
                    if (snapshot.hasError) {
                      return Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.error_outline, size: 48, color: Colors.red),
                            const SizedBox(height: 16),
                            Text('Error: ${snapshot.error}'),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: () => _loadUser(),
                              child: const Text('Retry'),
                            ),
                          ],
                        ),
                      );
                    }
                    
                    final teams = snapshot.data ?? [];
                    
                    // Use a key to only load counts when teams list actually changes
                    // This prevents infinite loops
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      if (mounted && teams.isNotEmpty && !_isLoadingCounts) {
                        _refreshPendingCounts(teams);
                      }
                    });
                    
                    return RefreshIndicator(
                      onRefresh: () async {
                        // Clear cache on manual refresh
                        _lastLoadedTeamIds = null;
                        await _loadUser();
                        if (teams.isNotEmpty) {
                          await _refreshPendingCounts(teams);
                        }
                      },
                      child: ListView(
                        padding: const EdgeInsets.all(16),
                        children: [
                          ...teams.map(
                            (team) => Dismissible(
                              key: ValueKey(team.id),
                              direction: DismissDirection.endToStart,
                              background: Container(
                                alignment: Alignment.centerRight,
                                padding: const EdgeInsets.only(right: 20),
                                color: Theme.of(context).colorScheme.error,
                                child: const Icon(Icons.exit_to_app,
                                    color: Colors.white),
                              ),
                              confirmDismiss: (_) async {
                                return await showDialog<bool>(
                                      context: context,
                                      builder: (ctx) => AlertDialog(
                                        title: const Text('Leave team?'),
                                        content: Text('Leave ${team.name}?'),
                                        actions: [
                                          TextButton(
                                            onPressed: () =>
                                                Navigator.pop(ctx, false),
                                            child: const Text('Cancel'),
                                          ),
                                          FilledButton(
                                            onPressed: () =>
                                                Navigator.pop(ctx, true),
                                            child: const Text('Leave'),
                                          ),
                                        ],
                                      ),
                                    ) ??
                                    false;
                              },
                              onDismissed: (_) => _leaveTeam(team),
                              child: Card(
                                margin: const EdgeInsets.only(bottom: 12),
                                child: ListTile(
                                  leading: Text(
                                    team.icon,
                                    style: const TextStyle(fontSize: 28),
                                  ),
                                  title: Text(team.name),
                                  subtitle: Text(
                                    '${team.memberCount} members · '
                                    '${_pendingCounts[team.id] ?? '0'} pending tasks',
                                  ),
                                  trailing: const Icon(Icons.chevron_right),
                                  onTap: () => context.push(
                                    '/teams/${team.id}/tasks',
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: () => context.push(AppRoutes.createTeam),
                            icon: const Icon(Icons.add),
                            label: const Text('CREATE TEAM'),
                          ),
                          const SizedBox(height: 8),
                          OutlinedButton.icon(
                            onPressed: () => context.push(AppRoutes.joinTeam),
                            icon: const Icon(Icons.link),
                            label: const Text('JOIN TEAM'),
                          ),
                        ],
                      ),
                    );
                  },
                ),
    );
  }
}

class _EmptyTeams extends StatelessWidget {
  const _EmptyTeams({required this.onCreate, required this.onJoin});

  final VoidCallback onCreate;
  final VoidCallback onJoin;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('No teams yet'),
            const SizedBox(height: 24),
            FilledButton(onPressed: onCreate, child: const Text('CREATE TEAM')),
            const SizedBox(height: 12),
            OutlinedButton(onPressed: onJoin, child: const Text('JOIN TEAM')),
          ],
        ),
      ),
    );
  }
}