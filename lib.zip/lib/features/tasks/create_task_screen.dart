import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:team_manager/models/team_member.dart';

import '../../core/errors/app_exception.dart';
import '../../cubits/auth/auth_cubit.dart';
import '../../models/team.dart';
import '../../models/app_user.dart';
import '../../services/task_service.dart';
import '../../services/team_service.dart';
import '../../services/user_service.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/error_banner.dart';

class CreateTaskScreen extends StatefulWidget {
  const CreateTaskScreen({super.key, required this.teamId});

  final String teamId;

  @override
  State<CreateTaskScreen> createState() => _CreateTaskScreenState();
}

class _CreateTaskScreenState extends State<CreateTaskScreen> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _selectedMembers = <String>{};
  DateTime? _dueDate;
  bool _loading = false;
  bool _loadingMembers = false;
  Team? _team;
  Map<String, AppUser> _userProfiles = {};

  @override
  void initState() {
    super.initState();
    _loadTeam();
  }

  Future<void> _loadTeam() async {
    final team = await context
        .read<TeamService>()
        .watchTeam(widget.teamId)
        .first;
    if (mounted) setState(() => _team = team);
  }

  Future<void> _fetchTeamMembers() async {
    if (_team == null || _team!.members.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No team members found')),
      );
      return;
    }

    setState(() {
      _loadingMembers = true;
      _userProfiles.clear();
    });

    try {
      final userService = context.read<UserService>();
      final Map<String, AppUser> profiles = {};
      
      for (final member in _team!.members) {
        try {
          final user = await userService.getUserProfile(member.userId);
          profiles[member.userId] = user;
        } catch (e) {
          print("error in get user profile ${e}");
        }
      }
      
      setState(() {
        _userProfiles = profiles;
        _loadingMembers = false;
      });
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Loaded ${profiles.length} team members'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      setState(() => _loadingMembers = false);
      print("error in get user profile ${e}");
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error loading members: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 2)),
      initialDate: _dueDate ?? DateTime.now(),
    );
    if (date != null) setState(() => _dueDate = date);
  }

  Future<void> _create() async {
    if (!_formKey.currentState!.validate()) return;
    final userId = context.read<AuthCubit>().state.userId;
    if (userId == null) return;

    setState(() => _loading = true);
    try {
      await context.read<TaskService>().createTask(
            teamId: widget.teamId,
            createdBy: userId,
            title: _titleController.text,
            description: _descController.text,
            assignedTo: _selectedMembers.toList(),
            dueDate: _dueDate,
          );
      if (mounted) context.pop();
    } on AppException catch (e) {
      if (mounted) showErrorSnackBar(context, e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String getMemberDisplayName(TeamMember member) {
    final profile = _userProfiles[member.userId];
    if (profile != null) {
      return profile.name; // Use 'name' field instead of 'displayName'
    }
    // If profile not loaded yet, show a loading indicator or the ID
    return member.userId.contains('@') 
        ? member.userId.split('@').first 
        : member.userId;
  }

  @override
  Widget build(BuildContext context) {
    final members = _team?.members ?? [];

    return Scaffold(
      appBar: AppBar(title: const Text('CREATE TASK')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppTextField(
                controller: _titleController,
                label: 'Task Title *',
                icon: Icons.title,
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Title is required' : null,
              ),
              const SizedBox(height: 16),
              AppTextField(
                controller: _descController,
                label: 'Description',
                icon: Icons.description_outlined,
                maxLines: 4,
              ),
              const SizedBox(height: 16),
              
              // Get Team Members Button
              ElevatedButton.icon(
                onPressed: _loadingMembers ? null : _fetchTeamMembers,
                icon: _loadingMembers
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.people),
                label: Text(_loadingMembers ? 'LOADING MEMBERS...' : 'GET TEAM MEMBERS'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
              ),
              
              const SizedBox(height: 16),
              
              // Show loading indicator while fetching members
              if (_loadingMembers)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Column(
                      children: [
                        CircularProgressIndicator(),
                        SizedBox(height: 16),
                        Text('Fetching team members...'),
                      ],
                    ),
                  ),
                ),
              
              // Show members list if loaded
              if (!_loadingMembers && _userProfiles.isNotEmpty) ...[
                const Divider(),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.group, size: 20),
                    const SizedBox(width: 8),
                    Text(
                      'Team Members (${_userProfiles.length})',
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
              ],
              
              // Display members with names
              ...members.map(
                (m) => CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(
                    getMemberDisplayName(m),
                    style: const TextStyle(fontWeight: FontWeight.w500),
                  ),
                  subtitle: Text(
                    'Role: ${m.role.value.toUpperCase()}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                  ),
                  value: _selectedMembers.contains(m.userId),
                  onChanged: (checked) {
                    setState(() {
                      if (checked == true) {
                        _selectedMembers.add(m.userId);
                      } else {
                        _selectedMembers.remove(m.userId);
                      }
                    });
                  },
                ),
              ),
              
              // Show message if no members
              if (members.isEmpty && !_loadingMembers)
                const Padding(
                  padding: EdgeInsets.all(32),
                  child: Center(
                    child: Text(
                      'No team members found',
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
                ),
              
              const SizedBox(height: 16),
              
              // Show selected members count
              if (_selectedMembers.isNotEmpty)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: Colors.blue.shade200),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.person_add, size: 16, color: Colors.blue.shade700),
                      const SizedBox(width: 8),
                      Text(
                        'Selected: ${_selectedMembers.length} member(s)',
                        style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.blue.shade700,
                        ),
                      ),
                    ],
                  ),
                ),
              
              const SizedBox(height: 16),
              
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text(
                  _dueDate == null
                      ? 'Pick due date'
                      : 'Due: ${_dueDate!.toLocal()}'.split(' ').first,
                ),
                trailing: const Icon(Icons.calendar_today),
                onTap: _pickDate,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _loading ? null : _create,
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('CREATE TASK'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}