import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../models/team.dart';
import '../../models/team_task.dart';
import '../../cubits/auth/auth_cubit.dart';
import '../../services/task_service.dart';
import '../../services/team_service.dart';

class TasksScreen extends StatefulWidget {
  const TasksScreen({super.key, required this.teamId});

  final String teamId;

  @override
  State<TasksScreen> createState() => _TasksScreenState();
}

class _TasksScreenState extends State<TasksScreen> {
  TaskFilter _filter = TaskFilter.all;

  @override
  Widget build(BuildContext context) {
    final taskService = context.read<TaskService>();
    final teamService = context.read<TeamService>();
    final userId = context.read<AuthCubit>().state.userId;

    return StreamBuilder<Team>(
      stream: teamService.watchTeam(widget.teamId),
      builder: (context, teamSnapshot) {
        final team = teamSnapshot.data;
        return Scaffold(
          appBar: AppBar(
            title: Text(team?.name ?? 'Tasks'),
            actions: [
              IconButton(
                icon: const Icon(Icons.group_outlined),
                onPressed: () => context.push(
                  '/teams/${widget.teamId}/members',
                ),
              ),
              PopupMenuButton<String>(
                onSelected: (value) {
                  if (value == 'members') {
                    context.push('/teams/${widget.teamId}/members');
                  }
                },
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'members', child: Text('Members')),
                ],
              ),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(12),
                child: SegmentedButton<TaskFilter>(
                  segments: const [
                    ButtonSegment(value: TaskFilter.all, label: Text('ALL')),
                    ButtonSegment(
                      value: TaskFilter.pending,
                      label: Text('PENDING'),
                    ),
                    ButtonSegment(value: TaskFilter.done, label: Text('DONE')),
                  ],
                  selected: {_filter},
                  onSelectionChanged: (s) =>
                      setState(() => _filter = s.first),
                ),
              ),
              Expanded(
                child: StreamBuilder<List<TeamTask>>(
                  stream: taskService.watchTasks(
                    widget.teamId,
                    filter: _filter,
                  ),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return const Center(child: CircularProgressIndicator());
                    }
                    final tasks = snapshot.data ?? [];
                    if (tasks.isEmpty) {
                      return const Center(child: Text('No tasks yet'));
                    }
                    return RefreshIndicator(
                      onRefresh: () async {},
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        itemCount: tasks.length,
                        itemBuilder: (context, index) {
                          final task = tasks[index];
                          return _TaskCard(
                            task: task,
                            userId: userId,
                            onTap: () => context.push(
                              '/teams/${widget.teamId}/tasks/${task.id}',
                            ),
                            onToggleDone: () async {
                              if (userId == null) return;
                              await taskService.markAssigneeDone(
                                teamId: widget.teamId,
                                taskId: task.id,
                                userId: userId,
                              );
                            },
                          );
                        },
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => context.push(
              '/teams/${widget.teamId}/tasks/create',
            ),
            label: const Text('ADD TASK'),
            icon: const Icon(Icons.add),
          ),
        );
      },
    );
  }
}

class _TaskCard extends StatelessWidget {
  const _TaskCard({
    required this.task,
    required this.userId,
    required this.onTap,
    required this.onToggleDone,
  });

  final TeamTask task;
  final String? userId;
  final VoidCallback onTap;
  final VoidCallback onToggleDone;

  @override
  Widget build(BuildContext context) {
    final isOverdue = task.dueDate != null &&
        task.dueDate!.isBefore(DateTime.now()) &&
        !task.isDone;
    final dueLabel = task.dueDate != null
        ? DateFormat.yMMMd().format(task.dueDate!)
        : 'No due date';

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${task.isDone ? '✓' : '📋'} ${task.title}',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                  ),
                  if (userId != null)
                    Checkbox(
                      value: task.assigneeStatus[userId] == 'done' ||
                          task.isDone,
                      onChanged: (_) => onToggleDone(),
                    ),
                ],
              ),
              if (task.assignedTo.isNotEmpty)
                Text('Assigned: ${task.assignedTo.length} member(s)'),
              Text(
                task.isDone ? '✅ Completed' : '⚠️ Due: $dueLabel',
                style: TextStyle(
                  color: isOverdue
                      ? Theme.of(context).colorScheme.error
                      : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
