import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/constants/firestore_paths.dart';
import '../../cubits/auth/auth_cubit.dart';
import '../../models/app_user.dart';
import '../../models/task_comment.dart';
import '../../services/comment_service.dart';
import '../../services/task_service.dart';
import '../../widgets/error_banner.dart';

class TaskDetailScreen extends StatefulWidget {
  const TaskDetailScreen({
    super.key,
    required this.teamId,
    required this.taskId,
  });

  final String teamId;
  final String taskId;

  @override
  State<TaskDetailScreen> createState() => _TaskDetailScreenState();
}

class _TaskDetailScreenState extends State<TaskDetailScreen> {
  final _commentController = TextEditingController();
  final _userNames = <String, String>{};

  @override
  void dispose() {
    _commentController.dispose();
    super.dispose();
  }

  Future<String> _userName(String userId) async {
    if (_userNames.containsKey(userId)) return _userNames[userId]!;
    final doc = await FirebaseFirestore.instance
        .doc(FirestorePaths.user(userId))
        .get();
    final name = doc.exists
        ? AppUser.fromFirestore(doc).name
        : 'Unknown';
    _userNames[userId] = name;
    return name;
  }

  Future<void> _addComment() async {
    final text = _commentController.text.trim();
    if (text.isEmpty) return;
    final userId = context.read<AuthCubit>().state.userId;
    if (userId == null) return;
    await context.read<CommentService>().addComment(
          teamId: widget.teamId,
          taskId: widget.taskId,
          userId: userId,
          text: text,
        );
    _commentController.clear();
  }

  @override
  Widget build(BuildContext context) {
    final taskService = context.read<TaskService>();
    final commentService = context.read<CommentService>();
    final userId = context.read<AuthCubit>().state.userId;

    return StreamBuilder(
      stream: taskService.watchTask(widget.teamId, widget.taskId),
      builder: (context, taskSnapshot) {
        if (!taskSnapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        final task = taskSnapshot.data!;

        return Scaffold(
          appBar: AppBar(
            title: Text(task.title),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                onPressed: () {
                  showErrorSnackBar(context, 'Edit task coming soon.');
                },
              ),
            ],
          ),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Status: ${task.isDone ? '✅ Done' : '□ Pending'}',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 16),
                const Text('Description',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                Text(task.description ?? 'No description'),
                const SizedBox(height: 16),
                const Text('Assigned to',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                ...task.assignedTo.map((id) {
                  final done = task.assigneeStatus[id] == 'done';
                  return FutureBuilder<String>(
                    future: _userName(id),
                    builder: (_, snap) {
                      final name = snap.data ?? '...';
                      return Text('• $name (${done ? 'Completed' : 'Pending'})');
                    },
                  );
                }),
                const SizedBox(height: 8),
                if (task.dueDate != null)
                  Text('Due: ${DateFormat.yMMMd().format(task.dueDate!)}'),
                Text('Created: ${DateFormat.yMMMd().format(task.createdAt)}'),
                const SizedBox(height: 16),
                Text('COMMENTS',
                    style: Theme.of(context).textTheme.titleMedium),
                StreamBuilder<List<TaskComment>>(
                  stream: commentService.watchComments(
                    widget.teamId,
                    widget.taskId,
                  ),
                  builder: (context, commentSnapshot) {
                    final comments = commentSnapshot.data ?? [];
                    return Column(
                      children: comments.map((c) {
                        return FutureBuilder<String>(
                          future: _userName(c.userId),
                          builder: (_, snap) {
                            return ListTile(
                              dense: true,
                              title: Text('${snap.data ?? '...'}: ${c.text}'),
                            );
                          },
                        );
                      }).toList(),
                    );
                  },
                ),
                TextField(
                  controller: _commentController,
                  decoration: const InputDecoration(
                    hintText: 'Add a comment...',
                  ),
                ),
                TextButton(
                  onPressed: _addComment,
                  child: const Text('ADD COMMENT'),
                ),
                const SizedBox(height: 24),
                if (userId != null)
                  FilledButton(
                    onPressed: () async {
                      await taskService.markAssigneeDone(
                        teamId: widget.teamId,
                        taskId: task.id,
                        userId: userId,
                      );
                    },
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('MARK AS DONE'),
                    ),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }
}
