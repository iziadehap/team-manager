import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:go_router/go_router.dart';

import '../../cubits/auth/auth_cubit.dart';
import '../../cubits/auth/auth_state.dart';
import '../../cubits/theme/theme_cubit.dart';
import '../../cubits/theme/theme_state.dart';
import '../../router/app_router.dart';
import '../../services/task_service.dart';
import '../../widgets/app_text_field.dart';
import '../../widgets/error_banner.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _nameController = TextEditingController();
  Map<String, int> _stats = {'completed': 0, 'pending': 0};
  bool _notifications = true;
  bool _editing = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final authCubit = context.read<AuthCubit>();
    await authCubit.loadProfile();
    final user = authCubit.state.profile;
    final userId = authCubit.state.userId;
    if (user != null) _nameController.text = user.name;
    if (userId != null && mounted) {
      final stats = await context.read<TaskService>().userTaskStats(userId);
      if (mounted) setState(() => _stats = stats);
    }
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _nameController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    try {
      await context.read<AuthCubit>().updateProfile(
            name: _nameController.text,
          );
      setState(() => _editing = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Profile saved')),
        );
      }
    } catch (e) {
      if (mounted) showErrorSnackBar(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<AuthCubit, AuthState>(
      builder: (context, authState) {
        return BlocBuilder<ThemeCubit, ThemeState>(
          builder: (context, themeState) {
            final email = authState.email ?? '';

            return Scaffold(
              appBar: AppBar(
                title: const Text('Profile'),
                actions: [
                  if (_editing)
                    TextButton(
                      onPressed: _save,
                      child: const Text('SAVE'),
                    ),
                ],
              ),
              body: ListView(
                padding: const EdgeInsets.all(24),
                children: [
                  const CircleAvatar(
                    radius: 48,
                    child: Icon(Icons.person, size: 48),
                  ),
                  const SizedBox(height: 16),
                  if (_editing)
                    AppTextField(
                      controller: _nameController,
                      label: 'Full Name',
                    )
                  else
                    Text(
                      _nameController.text.isEmpty
                          ? 'User'
                          : _nameController.text,
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                  Text(email, textAlign: TextAlign.center),
                  const SizedBox(height: 24),
                  ListTile(
                    leading: const Icon(Icons.edit_outlined),
                    title: const Text('Edit Profile'),
                    onTap: () => setState(() => _editing = !_editing),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.notifications_outlined),
                    title: const Text('Notifications'),
                    value: _notifications,
                    onChanged: (v) => setState(() => _notifications = v),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.dark_mode_outlined),
                    title: const Text('Dark Mode'),
                    value: themeState.mode == ThemeMode.dark,
                    onChanged: (v) =>
                        context.read<ThemeCubit>().setDarkMode(v),
                  ),
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.bar_chart),
                      title: const Text('My Stats'),
                      subtitle: Text(
                        'Completed: ${_stats['completed']} tasks\n'
                        'Pending: ${_stats['pending']} tasks',
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      backgroundColor: Theme.of(context).colorScheme.error,
                    ),
                    onPressed: () async {
                      await context.read<AuthCubit>().signOut();
                      if (context.mounted) context.go(AppRoutes.login);
                    },
                    icon: const Icon(Icons.logout),
                    label: const Text('LOGOUT'),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
